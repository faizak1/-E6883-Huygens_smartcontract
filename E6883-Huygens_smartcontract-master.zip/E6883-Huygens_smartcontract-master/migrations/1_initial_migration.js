const Verification = artifacts.require("Verification");

module.exports = function (deployer) {
  deployer.deploy(Verification);
};
